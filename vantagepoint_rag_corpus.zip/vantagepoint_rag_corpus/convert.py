import pdfplumber, glob, re, os, json
SRC='/mnt/user-data/uploads'
def runs_of(chars, colxs=()):
    runs=[];cur=[]
    for c in chars:
        brk=False
        if cur:
            p=cur[-1]
            if abs(c['top']-p['top'])>2 or c['x0']<p['x0']-1 or c['x0']-p['x1']>8: brk=True
            elif any(abs(c['x0']-x)<0.6 for x in colxs) and c['x0']-p['x1']>-0.5 and c['x0']>p['x0']+1 and p['text']!=' ' and False: brk=True
        if brk: runs.append(cur);cur=[]
        cur.append(c)
    if cur: runs.append(cur)
    return runs
def txt(r): return ''.join(c['text'] for c in r).strip()
def convert(path):
    out=[];title=None
    with pdfplumber.open(path) as pdf:
        for pi,p in enumerate(pdf.pages):
            tables=p.find_tables()
            bbs=[t.bbox for t in tables]
            def intable(top,x):
                return any(b[1]-2<=top<=b[3]+2 for b in bbs)
            chars=[c for c in p.chars if c['top']>45]  # drop running header (2 lines)
            allruns=runs_of(chars)
            # columns for each table from header-line cell starts
            items=[]  # (top, kind, payload)
            used=set()
            for t in tables:
                # runs in table
                tr=[r for r in allruns if t.bbox[1]-2<=r[0]['top']<=t.bbox[3]+2]
                # re-split runs at column starts by stream order using x0 proximity to header positions
                cx=sorted(set(round(c[0],1) for c in t.cells))
                pad=min(r[0]['x0'] for r in tr)-cx[0]
                hx=[x+pad for x in cx]
                newruns=[]
                for r in tr:
                    cur=[]
                    for c in r:
                        if cur and any(abs(c['x0']-x)<0.8 for x in hx) and cur[-1]['x1']<=c['x0']+0.5 and (cur[-1]['text'].islower() or cur[-1]['text'].isdigit() or cur[-1]['text'] in ')%') and (c['text'].isupper() or c['text'].isdigit() or c['text'] in '$('):
                            newruns.append(cur);cur=[]
                        cur.append(c)
                    newruns.append(cur)
                # group by row top
                rowsd={}
                for r in newruns:
                    key=None
                    for k in rowsd:
                        if abs(k-r[0]['top'])<3: key=k;break
                    if key is None: key=r[0]['top']; rowsd[key]=[]
                    rowsd[key].append(r)
                trows=[]
                for k in sorted(rowsd):
                    cells=['']*len(hx)
                    for r in sorted(rowsd[k],key=lambda r:r[0]['x0']):
                        i=max([j for j,x in enumerate(hx) if r[0]['x0']>=x-1] or [0])
                        cells[i]=(cells[i]+' '+txt(r)).strip()
                    trows.append(cells)
                md=['| '+' | '.join(trows[0])+' |','|'+'---|'*len(hx)]
                for r in trows[1:]: md.append('| '+' | '.join(x.replace('|','/') for x in r)+' |')
                items.append((t.bbox[1],'table','\n'.join(md)))
                for r in tr: used.add(id(r))
            for r in allruns:
                if id(r) in used: continue
                if any(b[1]-2<=r[0]['top']<=b[3]+2 for b in bbs): continue
                s=txt(r)
                if not s or re.match(r'^Confidential — Internal',s): continue
                size=round(r[0]['size'],1); bold='Bold' in r[0]['fontname']
                items.append((r[0]['top'],'line',(s,size,bold,r[0]['x0'],r[0]['top'])))
            items.sort(key=lambda x:x[0])
            for _,k,v in items:
                out.append((k,v))
    return out

def to_md(items):
    md=[];para=[];last=None;title=[]
    def flush():
        nonlocal para
        if para: md.append(' '.join(para)); para=[]
    for k,v in items:
        if k=='table': flush(); md.append(v); last=None; continue
        s,size,bold,x,top=v
        s=s.replace('(cid:127)','•')
        if re.match(r'^VANTAGEPOINT TECHNOLOGIES INC\. \|',s) or re.match(r'^Page \d+$',s): continue
        if size>=19:
            flush(); title.append(s); continue
        if title:
            md.append('# '+' '.join(title)); title=[]
        gap = None if last is None else top-last
        last=top
        if size>=13: flush(); md.append('## '+s); continue
        if size>=11 and bold: flush(); md.append('### '+s); continue
        if s.startswith('Document ID:'):
            flush(); para=['*'+s]; continue
        if para and para[0].startswith('*Document ID') and not para[0].endswith('*'):
            para[0]+=' '+s+'*'; continue
        if s.startswith('•'):
            flush(); para=['- '+s[1:].strip()]; continue
        if gap is not None and gap>17 and not (para and para[0].startswith('- ') and x>70): flush()
        para.append(s)
    flush()
    if title: md.append('# '+' '.join(title))
    out='\n\n'.join(md)
    out=re.sub(r'\n\n(\| )',r'\n\n\1',out)
    return out+'\n'
if __name__=='__main__':
    for p in sorted(glob.glob(SRC+'/*.pdf')):
        name=os.path.basename(p)[3:-4]
        items=convert(p)
        open('md/'+name+'.md','w').write(to_md(items))
        print(name, len(to_md(items)))

# ---- known fix-ups for two cells where adjacent text ran together in the source text layer
FIXUPS={
 'POL-HR-002_PTO_Holidays_and_Sick_Leave.md':[
  ("| Biweekly Accrual RateMaximum Rollover Cap |  |","| Biweekly Accrual Rate | Maximum Rollover Cap |"),
  ("| December 24 – Dec 31, 2026Thu – Thu |  |","| December 24 – December 31, 2026 | Thursday – Thursday |"),
 ]}
def apply_fixups():
    for fn,subs in FIXUPS.items():
        p='md/'+fn; s=open(p).read()
        for a,b in subs:
            assert a in s,(fn,a); s=s.replace(a,b)
        open(p,'w').write(s)
