"""Inline chunks + HRIS snapshot into assistant/template.html -> assistant/vantagepoint_hr_assistant.html"""
import json, os
ROOT=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
chunks=json.load(open(os.path.join(ROOT,'chunks.json')))
for c in chunks: c.pop('has_table',None)
hris=json.load(open(os.path.join(ROOT,'hris_data','vantagepoint_hris_master_bundle.json')))
dump=lambda o:json.dumps(o,ensure_ascii=False,separators=(',',':')).replace('</','<\\/')
t=open(os.path.join(ROOT,'assistant','template.html')).read()
t=t.replace('/*CHUNKS*/',dump(chunks)).replace('/*HRIS*/',dump(hris))
out=os.path.join(ROOT,'assistant','vantagepoint_hr_assistant.html')
open(out,'w').write(t); print('wrote',out,len(t)//1024,'KB')
