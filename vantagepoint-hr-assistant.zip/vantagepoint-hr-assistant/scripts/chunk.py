"""Split markdown policies into retrieval chunks (one per section, <=~1400 chars) with metadata."""
import re, glob, json, os
ROOT=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
MAXLEN=1400
chunks=[]
for f in sorted(glob.glob(os.path.join(ROOT,'markdown','*.md'))):
    s=open(f).read()
    pid=re.search(r'POL-[A-Z]+-\d+',os.path.basename(f)).group(0)
    title=re.search(r'^# (.+)$',s,re.M).group(1)
    meta=re.search(r'\*Document ID:(.+?)\*',s,re.S).group(1)
    ver=re.search(r'Version: ([\d.]+)',meta).group(1)
    eff=re.search(r'Effective\s*Date: (.+?)$',meta.strip()).group(1).strip()
    cur_h2=''
    for part in re.split(r'\n(?=#{2,3} )',s):
        m=re.match(r'(#{2,3}) (.+)',part)
        if not m: continue
        lvl,head=m.groups()
        if lvl=='##': cur_h2=head
        body=part[m.end():].strip()
        if not body: continue
        num=re.match(r'(\d+(?:\.\d+)?)\.? ',head); sec=num.group(1) if num else ''
        crumb=f"{pid} {title} > {cur_h2}"+(f" > {head}" if lvl=='###' else '')
        pieces=[];cur=''
        for b in body.split('\n\n'):
            if cur and len(cur)+len(b)>MAXLEN: pieces.append(cur);cur=''
            cur+=('\n\n' if cur else '')+b
        if cur: pieces.append(cur)
        for i,pc in enumerate(pieces):
            chunks.append({'id':f"{pid}-{sec or 'x'}-{i+1}",'policy_id':pid,'policy_title':title,'version':ver,
              'effective':eff,'section':sec,'heading':head,'breadcrumb':crumb,'text':pc,'has_table':'|---' in pc})
json.dump(chunks,open(os.path.join(ROOT,'chunks.json'),'w'),indent=1,ensure_ascii=False)
with open(os.path.join(ROOT,'chunks.jsonl'),'w') as fh:
    for c in chunks: fh.write(json.dumps(c,ensure_ascii=False)+'\n')
print(len(chunks),'chunks written')
