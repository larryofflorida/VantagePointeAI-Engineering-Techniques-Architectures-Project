# Information Security, Data Classification & Acceptable Use Policy

*Document ID: POL-SEC-001  |  Version: 5.3  |  Owner: Information Security & GRC  |  Effective Date: February 15, 2026*

## 1. Purpose & Security Governance

As an enterprise SaaS provider maintaining SOC 2 Type II, ISO 27001, and HIPAA compliance, VantagePoint entrusts every employee with safeguarding company intellectual property and customer data. Compliance with this policy is mandatory for all employees, contractors, interns, and third-party vendors.

## 2. Four-Tier Data Classification Standard

All documents, databases, Slack channels, and code repositories must be handled according to their sensitivity level:

| Classification Level | Definition & Examples | Storage & Transmission Controls |
|---|---|---|
| Level 1: Public | Approved marketing collateral, public website content, press releases, job postings | No encryption required; may be shared externally without NDA |
| Level 2: Internal | Org charts, internal policies, general Slack discussions, non-sensitive roadmaps | Must remain inside authenticated VantagePoint Workspace/Slack; no public posting |
| Level 3: Confidential | Financial forecasts, M&A plans, source code, non-public pricing, employee salaries | Encrypted at rest (AES-256) and in transit (TLS 1.3); RBAC access; NDA required for external sharing |
| Level 4: Restricted (PII/PHI/Secrets) | Customer production data, SSNs, bank details, API keys, passwords, encryption keys | Zero-trust hardware MFA required; prohibited in email attachments, Slack DMs, or local downloads |

## 3. Access Control, Authentication & Password Hygiene

- Single Sign-On & Hardware MFA: All corporate applications must be accessed through Okta SSO protected by phishing-resistant FIDO2/WebAuthn MFA (YubiKey 5C NFC or Okta FastPass biometric). SMS-based MFA is prohibited.
- Enterprise Password Manager: Employees must use 1Password Enterprise for all non-SSO credentials. Passwords must be unique, randomly generated, and at least 16 characters long. Sharing passwords via Slack, email, or sticky notes is strictly forbidden.
- Screen Lock & Clean Desk: Workstations must auto-lock after 5 minutes of inactivity. Employees working in hubs, cafes, or airplanes must lock their screen manually (Cmd+Ctrl+Q / Win+L) whenever stepping away and use privacy screen filters in public spaces.
- Least Privilege Access: Access to production environments and Level 4 Restricted datasets requires formal JIT (Just-In-Time) elevation via ConductorOne with manager approval and automatically expires after 4 hours.

## 4. Generative AI & Third-Party Tools Usage

VantagePoint encourages responsible productivity gains from approved AI tools while preventing data leakage and IP contamination:

- Approved Enterprise AI Tools: Only VantagePoint's enterprise-licensed AI instances (Google Workspace Gemini Enterprise, Claude Enterprise, and GitHub Copilot Business—all governed by zero-data-retention BAAs) may be used for company work.
- Prohibited Input into Consumer AI: Employees must NEVER paste Level 3 (Confidential) or Level 4 (Restricted) data, proprietary source code, customer names, or PII into public/free consumer AI accounts (e.g., personal ChatGPT, public Claude, free Gemini, or unapproved browser extensions).
- Human Review: AI-generated code, legal language, or external customer communications must be reviewed and verified by a human employee before deployment or transmission.

## 5. Phishing, Removable Media & Network Security

### 5.1 Public Wi-Fi & VPN Requirements

When connecting from airports, hotels, cafes, or co-working spaces, employees must activate Cloudflare WARP Zero-Trust VPN prior to accessing internal resources. Connecting to unencrypted public Wi-Fi without VPN active is blocked by endpoint policy.

### 5.2 USB & Removable Media

USB flash drives, external hard drives, and SD cards are blocked by default via CrowdStrike Falcon Device Control. Temporary read/write exceptions for engineering hardware testing require a security ticket approved by the CISO's office.

### 5.3 Security Incident Reporting SLA

If you suspect a phishing email, credential compromise, accidental data exposure, or malware infection, report it immediately using the 'Report Phish' button in Gmail or by messaging #security-incidents (or calling +1-800-555-0199) within 30 minutes. VantagePoint maintains a blameless reporting culture—employees who promptly report honest mistakes will not face disciplinary action.

## 6. Security Awareness Training & Data Retention

### 6.1 Training & Phishing Simulations

All employees must complete annual Security Awareness & Privacy Training within 30 days of assignment. InfoSec conducts monthly unannounced phishing simulations. Employees who click a simulated phishing link must complete a 10-minute micro-training module; three consecutive simulation failures within a 6-month window trigger mandatory coaching with InfoSec and the employee's manager.

### 6.2 Data Retention & Secure Disposal

Slack direct messages and private channels retain messages for 365 days unless placed on Legal Hold. Customer production snapshots in staging environments are prohibited; anonymized synthetic datasets must be used for QA testing.
