# Corporate Travel & Expense Reimbursement Policy

*Document ID: POL-FIN-001  |  Version: 6.1  |  Owner: Finance & Accounting Operations  |  Effective Date: March 1, 2026*

## 1. Core Principles & Submission Deadlines

VantagePoint reimburses employees for reasonable, necessary, and properly documented business expenses incurred while conducting company business. Employees are expected to spend company funds with the same prudence they exercise with personal funds.

- Booking Platform: All flights, hotels, and rental cars must be booked through Navan (formerly TripActions) using your corporate virtual card or linked personal card.
- 30-Day Submission Rule: Expense reports must be submitted in Expensify within 30 calendar days of the transaction date (or trip completion date). Expenses submitted more than 60 days after the transaction date require VP of Finance exception approval and may be treated as taxable income under IRS accountable plan rules.
- Itemized Receipts: Itemized receipts showing vendor name, date, individual items purchased, tax, and proof of payment are mandatory for all expenses of $25.00 or more (and for ALL lodging, airfare, rental car, and alcohol charges regardless of amount). Credit card summary slips alone are insufficient.

## 2. Air Travel & Rail Guidelines

| Travel Category | Booking Lead Time | Permitted Cabin Class | Seat Selection & Upgrades |
|---|---|---|---|
| Domestic Flights (< 5 hours) | At least 14 days in advance | Main Cabin / Standard Economy | Standard aisle/window seat fees reimbursable; Extra Legroom allowed for employees >6'2" |
| Long-Haul Domestic / Transcontinental (>= 5 hrs) | At least 14 days in advance | Main Cabin or Economy Plus / Comfort+ | Preferred/Extra Legroom seat selection reimbursable up to $120 each way |
| International Flights (>= 6 hours) | At least 21 days in advance | Premium Economy (Business Class for VPs+ or overnight flights >10 hrs with immediate morning client meeting) | Airport lounge day pass reimbursable up to $65 if layover > 3 hours |
| Amtrak / High-Speed Rail | At least 7 days in advance | Business Class (Acela / Regional) | Preferred over short-haul flights under 250 miles (e.g., NYC–DC, NYC–Boston) |

Employees may retain personal frequent flyer miles and hotel loyalty points earned on business travel, provided loyalty preferences do not increase ticket cost by more than $50 over the lowest logical fare in Navan.

## 3. Lodging & Ground Transportation

### 3.1 Hotel Nightly Rate Caps (Pre-Tax)

Employees should select standard single-occupancy rooms at corporate-rate hotels in Navan within the following nightly pre-tax caps:

- Tier A High-Cost Cities (New York City, San Francisco, London, Tokyo, Zurich): Up to $375 / night.
- Tier B Major Hubs & Metros (Miami, Seattle, Austin, Boston, Chicago, Los Angeles, Washington D.C.): Up to $275 / night.
- Tier C All Other Domestic & International Cities: Up to $210 / night.

Conference host hotels exceeding these caps by up to 20% are automatically approved if booked through the official conference room block. Incidentals such as in-room movies, minibar alcohol, spa services, and dry cleaning (for trips under 5 nights) are non-reimbursable.

### 3.2 Ground Transportation & Mileage

- Rideshare & Taxis: UberX, Lyft Standard, or licensed taxis are reimbursable for airport transfers and business transit. Uber Black/Lux is permitted only when traveling with 3+ colleagues or for safety reasons late at night (after 10:00 PM).
- Rental Cars: Intermediate/Midsize class booked via Navan (National/Enterprise corporate code includes primary CDW/LDW insurance—decline rental counter collision waivers for domestic rentals). Fuel must be refilled prior to return.
- Personal Vehicle Mileage: Reimbursed at the 2026 IRS standard mileage rate of $0.70 per mile for business travel exceeding the employee's normal daily commute.

## 4. Meals, Per Diem & Client Entertainment

### 4.1 Daily Travel Meal Caps (Individual Travel)

VantagePoint reimburses actual meal expenses (including tax and up to 20% tip) up to the following daily maximums while traveling overnight on business:

| Meal Period | Standard U.S. Cities | Tier A High-Cost Cities (NYC, SF, London, etc.) |
|---|---|---|
| Breakfast | Up to $20 | Up to $25 |
| Lunch | Up to $25 | Up to $35 |
| Dinner | Up to $45 | Up to $60 |
| Daily Combined Cap | $90 / day | $120 / day |

### 4.2 Client Meals & Team Dinners

- Client Entertainment: Reimbursable up to $125 per person (inclusive of tax, tip, and moderate alcohol—max 2 drinks per attendee). Expensify entry must list the full names, titles, and company names of all external attendees plus the business purpose.
- Internal Team Meals: Manager-approved team celebrations or offsite dinners are capped at $65 per employee (including tax and tip) and require prior department budget sign-off.

## 5. Corporate Credit Cards, Non-Reimbursables & Audit

### 5.1 Corporate Brex / Amex Virtual Cards

Employees who travel 3 or more times per year or manage recurring SaaS/event budgets may request a corporate Brex card in Rippling. Personal charges on corporate cards are strictly prohibited; accidental personal swipes must be repaid within 10 business days via Expensify.

### 5.2 Non-Reimbursable Expenses & Audit Enforcement

The following items are strictly non-reimbursable under all circumstances: parking tickets or traffic/speeding violations, airline club annual memberships, TSA PreCheck/Global Entry fees (covered separately via wellness perk), childcare/pet boarding during travel, political contributions, and personal gifts.

Finance audits 100% of expenses over $500 and a random 15% sample of all other reports. Approved reimbursements are deposited via ACH within 5 business days of manager and Finance sign-off. Submitting falsified receipts or duplicate claims constitutes gross misconduct under POL-ETH-001 and may result in immediate termination.
