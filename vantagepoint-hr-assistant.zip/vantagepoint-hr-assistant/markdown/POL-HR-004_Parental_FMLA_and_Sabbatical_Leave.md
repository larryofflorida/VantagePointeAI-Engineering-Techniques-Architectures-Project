# Parental Leave, Family & Medical Leave (FMLA) & Sabbatical Policy

*Document ID: POL-HR-004  |  Version: 3.1  |  Owner: People Operations & Leave Administration  |  Effective Date: January 1, 2026*

## 1. Overview of Extended Leaves

VantagePoint supports employees through major life milestones, serious health events, and long-term career renewal. All extended leaves exceeding five (5) consecutive business days are administered through our leave partner, Sparrow, in coordination with People Operations.

## 2. Paid Parental Leave

VantagePoint provides gender-neutral, 100% base-pay Paid Parental Leave to support new parents following the birth, adoption, or foster placement of a child. Company parental leave runs concurrently with federal FMLA, state CFRA/PFML, and Short-Term Disability (STD) benefits, with VantagePoint topping up state/STD wage replacement to equal 100% of regular base salary.

| Parent Role / Category | Paid Leave Duration | Eligibility Requirement | Scheduling Flexibility |
|---|---|---|---|
| Birthing Parent | 16 weeks (6–8 wks STD medical recovery + 8–10 wks bonding) | Completed 6 months of continuous full-time service prior to due/placement date | May be taken continuously or split into up to 2 blocks within 12 months of birth |
| Non-Birthing / Adoptive / Foster Parent | 12 weeks paid bonding leave | Completed 6 months of continuous full-time service prior to due/placement date | May be taken continuously or split into up to 2 blocks within 12 months of placement |
| New Hires (< 6 Months Tenure) | 6 weeks paid bonding leave | Active full-time status on birth/placement date | Remaining balance (up to 12/16 wks) unlocks upon hitting 6-month anniversary if within 12 mos |

### 2.1 Gradual Return-to-Work Ramp & Lactation Support

- 4-Week Phase-Back Schedule: Returning parents may work a 4-day (80%) schedule at 100% full-time pay during their first 4 weeks back from parental leave.
- Lactation Accommodations: All VantagePoint hubs provide private, badge-restricted Wellness/Mother's Rooms equipped with hospital-grade sinks, refrigerators, and comfortable seating. Traveling nursing parents may expense Milk Stork breast milk shipping via Expensify (code: PARENTAL-TRAVEL).

## 3. Family & Medical Leave Act (FMLA) & Medical Leave

Under the federal Family and Medical Leave Act (FMLA), eligible employees who have worked for VantagePoint for at least 12 months and logged at least 1,250 hours in the preceding 12 months may take up to 12 weeks of job-protected leave in a rolling 12-month period for:

- The birth, adoption, or foster care placement of a child (within 12 months of the event);
- A serious health condition that makes the employee unable to perform the essential functions of their job;
- Caring for a spouse, child, or parent with a serious health condition;
- Qualifying exigencies arising out of a family member's covered active military duty (or up to 26 weeks to care for a covered servicemember with a serious injury or illness).

### 3.1 Pay & Benefits Continuation During Medical Leave

For an employee's own serious health condition exceeding 7 consecutive calendar days, VantagePoint's company-paid Short-Term Disability (STD) plan provides 100% of base pay for Weeks 2–6 and 80% of base pay for Weeks 7–12 (accrued PTO or sick leave may be applied to cover the 7-day elimination period and the 20% gap in Weeks 7–12). Health, dental, and vision insurance remain active at standard employee contribution rates during all approved FMLA/STD leaves.

## 4. Paid Tenure Sabbatical Program

To recognize sustained loyalty and prevent burnout, VantagePoint grants a 4-week (20 business days) Paid Sabbatical to regular full-time employees upon completing every five (5) consecutive years of full-time service (Year 5, Year 10, Year 15, etc.).

- Scheduling & Notice: Sabbaticals must be scheduled at least 90 days in advance with manager and Department Head approval and must be taken within 18 months of the milestone anniversary.
- Combining with PTO: Employees may combine up to 5 days of accrued PTO with their 4-week sabbatical for a maximum consecutive absence of 5 weeks.
- Forfeiture & Non-Payout: Sabbatical leave has no cash value, cannot be carried over beyond the 18-month window, and is not paid out upon termination or resignation.

## 5. Personal Unpaid Leave of Absence & Military Leave

- Personal Unpaid Leave: Employees with at least 1 year of tenure may request up to 30 calendar days of unpaid personal leave for compelling personal or educational reasons after exhausting accrued PTO, subject to VP People Ops approval.
- Military Leave (USERRA): VantagePoint complies fully with USERRA and provides differential pay (the difference between military base pay and VantagePoint base pay) for up to 90 days per year for National Guard or Reserve training and active duty deployments.
