# Health, Welfare, Retirement (401k) & Wellness Benefits Guide

*Document ID: POL-BEN-001  |  Version: 2026.1  |  Owner: Total Rewards & Benefits Administration  | Effective Date: January 1, 2026*

## 1. Benefit Eligibility & Enrollment Windows

Regular full-time employees scheduled to work 30 or more hours per week are eligible for VantagePoint's comprehensive Total Rewards program. Coverage begins on the first day of the month coinciding with or immediately following the employee's hire date (e.g., an employee starting March 10 becomes covered April 1; an employee starting April 1 is covered April 1).

- New Hire Enrollment Window: Employees have strictly 30 calendar days from their hire date to submit elections in Rippling Benefits. Missing this window defaults the employee to waived coverage until the next Open Enrollment.
- Eligible Dependents: Legal spouse, registered domestic partner, and dependent children (biological, adopted, stepchildren, or legal guardianship) up to age 26.
- Qualifying Life Events (QLE): Mid-year benefit changes are permitted only within 30 calendar days of a documented IRS Qualifying Life Event (marriage, birth/adoption, divorce, or loss of other group coverage).

## 2. Medical, Dental & Vision Plans (2026 Plan Year)

VantagePoint subsidizes 90% of employee-only premiums and 75% of dependent premiums across three medical plan options administered by Aetna (or Kaiser Permanente HMO in California and Washington):

| Plan Feature | Aetna HDHP + HSA | Aetna PPO Core | Aetna PPO Premier |
|---|---|---|---|
| Annual Deductible (Ind / Fam) | $1,650 / $3,300 | $750 / $1,500 | $250 / $500 |
| Out-of-Pocket Max (Ind / Fam) | $4,000 / $8,000 | $3,000 / $6,000 | $2,000 / $4,000 |
| Preventive Care | 100% Covered ($0) | 100% Covered ($0) | 100% Covered ($0) |
| Primary Care / Specialist Copay | 10% after deductible | $25 PCP / $45 Specialist | $15 PCP / $30 Specialist |
| Biweekly Employee Contribution (EE Only) | $32.00 / paycheck | $68.00 / paycheck | $115.00 / paycheck |
| Company HSA Seed Contribution | $1,000 Ind / $2,000 Fam (deposited Jan & Jul) | Not Eligible (FSA Eligible) | Not Eligible (FSA Eligible) |

- Dental & Vision: Delta Dental PPO (covers 100% preventive, 80% basic, 50% major up to $2,500/yr; $2,000 lifetime orthodontia) and VSP Vision Plus ($0 exam, $250 frame/contact lens allowance annually). VantagePoint pays 100% of employee-only dental and vision premiums.

## 3. 401(k) Retirement Savings Plan

VantagePoint sponsors a tax-advantaged 401(k) plan administered by Fidelity Investments featuring Traditional pre-tax, Roth after-tax, and Mega Backdoor Roth in-plan conversion options (up to the 2026 IRS IRC §415(c) total additions limit).

- Automatic Enrollment: New hires are automatically enrolled at a 6% pre-tax contribution rate after 30 days unless they opt out or adjust their deferral percentage in Fidelity NetBenefits.
- Employer Match: VantagePoint matches 100% of employee contributions up to 4% of eligible compensation, plus 50% on the next 2% (a maximum 5% company match when the employee contributes 6% or more). Matching contributions are deposited per pay period with no year-end 'last day' requirement.
- Vesting Schedule: Employee contributions are 100% vested immediately. Employer matching contributions vest on a 2-year schedule: 50% vested after 1 year of service and 100% vested after 2 years of service.

## 4. Life, Disability & Family Building Benefits

- Basic Life & AD&D; Insurance: Company-paid coverage equal to 2x annual base salary (up to $500,000 maximum), with optional supplemental coverage available for purchase.
- Short-Term & Long-Term Disability: 100% company-paid STD (see POL-HR-004) and LTD providing 60% of monthly pre-disability earnings up to $15,000/month after a 90-day elimination period.
- Carrot Fertility & Adoption Assistance: Up to $20,000 lifetime reimbursement for IVF, egg/sperm freezing, surrogacy, or adoption agency and legal fees (see also POL-HR-004 for Parental Leave).

## 5. Wellness, Mental Health, Commuter & Learning Stipends

- Modern Health Mental Wellness: 12 free 1-on-1 therapy sessions and 12 free coaching sessions per calendar year for employees and their dependents, plus 24/7 crisis support.
- Quarterly Wellness & Fitness Reimbursement ($150/quarter): Up to $600/year reimbursed via Forma for gym memberships, fitness classes, ergonomic footwear, meditation apps, or massage therapy. Quarterly balances expire at the end of each calendar quarter.
- Annual Learning & Development Budget ($1,500/year): Reimbursable via Expensify (with manager approval) for job-related conferences, certifications, courses, and technical books. Unused funds do not roll over to the next calendar year.
- Commuter Benefits: Pre-tax payroll deductions up to the 2026 IRS statutory limit ($325/month) for mass transit and qualified parking, plus a $75/month company transit subsidy for Miami, Austin, and Seattle hub employees.
