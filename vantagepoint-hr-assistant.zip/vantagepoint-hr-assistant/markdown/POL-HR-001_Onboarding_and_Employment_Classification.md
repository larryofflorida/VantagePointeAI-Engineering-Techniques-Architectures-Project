# Employee Onboarding & Employment Classification Policy

*Document ID: POL-HR-001  |  Version: 4.2  |  Owner: People Operations & Talent Acquisition  |  Effective Date: January 1, 2026*

## 1. Purpose and Scope

VantagePoint Technologies Inc. ('VantagePoint' or the 'Company') is committed to providing a structured, transparent, and welcoming onboarding experience for every new team member. This policy defines employment classifications, pre-boarding compliance requirements, the 90-day onboarding roadmap, relocation assistance, and buddy mentorship standards across all U.S. hubs (Miami HQ, Austin, Seattle, New York) and Designated Remote locations.

All full-time, part-time, fixed-term, and intern employees must complete the onboarding milestones detailed herein. Independent contractors and agency workers are governed separately under POL-PROC-004 and receive modified security orientation under POL-SEC-001.

## 2. Employment Classifications

Each role at VantagePoint is assigned an official classification upon offer issuance. Classification determines eligibility for Paid Time Off (POL-HR-002), Health & Welfare Benefits (POL-BEN-001), Parental & Medical Leaves (POL-HR-004), and Equipment Stipends (POL-IT-001).

| Classification | Scheduled Hours | FLSA Status | Benefits & PTO Eligibility |
|---|---|---|---|
| Regular Full-Time (Exempt) | 40+ hrs/week | Exempt (Salaried) | Full medical/dental/vision, 401(k) match, Tiered PTO, $1,000 WFH stipend |
| Regular Full-Time (Non-Exempt) | 40 hrs/week | Non-Exempt (Hourly) | Full medical/dental/vision, 401(k) match, Tiered PTO, overtime eligible (>40 hrs/wk) |
| Regular Part-Time | 20–29 hrs/week | Non-Exempt (Hourly) | Prorated PTO (50%), 401(k) eligibility after 6 months, EAP access; no medical plan |
| Fixed-Term / Seasonal | Up to 40 hrs/week (<6 mos) | Non-Exempt or Exempt | Statutory sick leave only; Company-loaned laptop; ineligible for annual bonus |
| Paid Intern / Co-op | 20–40 hrs/week (10–16 wks) | Non-Exempt (Hourly) | Accrues 1 hour sick leave per 30 hours worked; company-loaned laptop; commuter pass |

### 2.1 Introductory Evaluation Period

All newly hired regular employees complete a 90-calendar-day Introductory Period beginning on their official start date. During this period, managers conduct formal check-ins at Day 30, Day 60, and Day 90. Successful completion does not alter at-will employment status, nor does it delay access to accrued PTO (which may be used starting Day 1 upon manager approval).

## 3. Pre-Boarding & Day 1 Compliance Requirements

To prevent delays in payroll setup, benefits enrollment, and hardware delivery, candidates must complete all pre-boarding tasks in Workday at least five (5) business days prior to their start date.

- Background Check & Offer Contingencies: Offers are contingent upon successful completion of criminal history, employment verification, and (for finance/security roles) credit screening via Checkr.
- Form I-9 Employment Eligibility Verification: Section 1 must be completed on or before Day 1. Section 2 physical or authorized E-Verify remote document inspection must be completed no later than Day 3 (72 hours after start). Failure to complete Form I-9 by Day 3 results in mandatory unpaid administrative suspension until resolved.
- Tax Withholding & Direct Deposit: Federal Form W-4, applicable state tax forms, and ACH bank routing details must be entered in Workday prior to the first payroll cutoff (the 10th and 25th of each month).
- Mandatory Agreements: Signed Proprietary Information and Inventions Agreement (PIIA), Mutual Arbitration Agreement, and Code of Conduct Acknowledgment (POL-ETH-001).

Hardware Delivery SLA: IT Operations ships standard laptop kits 7 business days before the start date once background checks clear. If a start date is rescheduled within 5 business days of onboarding, hardware arrival may shift by 2–3 business days.

## 4. Structured 30-60-90 Day Onboarding Roadmap

| Phase | Timeline | Key Milestones & Mandatory Trainings | Owner |
|---|---|---|---|
| Phase 1: Foundations | Week 1 (Days 1–5) | Live HR Welcome Orientation (Mon 10:00 AM EST), Okta/SSO & 1Password setup, Security Awareness 101 (POL-SEC-001), Meet Onboarding Buddy | People Ops & IT |
| Phase 2: Immersion | Days 6–30 | Anti-Harassment & Workplace Conduct training (due Day 14), Benefits elections in Rippling (strict 30-day window), Role-specific shadowing, 30-Day Manager Alignment | Hiring Manager & Employee |
| Phase 3: Contribution | Days 31–60 | First independent project deliverable, Cross-functional stakeholder introductions, 60-Day Feedback & Goal Calibration | Hiring Manager |
| Phase 4: Integration | Days 61–90 | 90-Day Onboarding Survey, Final Introductory Review, Career Development Plan setup in Lattice | Employee & People Partner |

## 5. Onboarding Buddy Program & Relocation Support

### 5.1 Onboarding Buddy Assignment

Every new hire is paired with a trained peer Onboarding Buddy from an adjacent team (not in their direct reporting line) for their first 60 days. Buddies host at least two 30-minute coffee chats in Week 1 and weekly check-ins through Week 8 to help navigate internal tools (Slack, Confluence, Jira, Expensify) and company culture. Buddies receive a $75 lunch stipend via Expensify (code ONBOARD-BUDDY) to host an in-person or virtual meal.

### 5.2 Relocation Assistance

Employees hired into approved hub-relocation roles (Miami HQ, Austin, or Seattle) are eligible for relocation packages tiered by career level, subject to a 12-month repayment clawback agreement if the employee voluntarily resigns within one year of relocation:

- Tier 1 (Individual Contributors L1–L4): Up to $5,000 lump-sum relocation allowance (taxable) plus 14 days temporary corporate housing.
- Tier 2 (Senior ICs L5–L6 & Managers): Up to $10,000 direct-billed household goods movement plus $2,500 settling-in allowance and 30 days corporate housing.
- Tier 3 (Directors & VPs): Full white-glove relocation managed via Cartus Relocation Services, up to $25,000 cap.

## 6. Rehires & Internal Transfers

Former VantagePoint employees rehired within 12 months of voluntary separation in good standing retain their original tenure date for PTO accrual tiers (POL-HR-002) and 401(k) vesting (POL-BEN-001). Rehires after more than 12 months are treated as new hires for accrual and benefit waiting periods.

Internal transfers between departments require a minimum of 12 months in the current role, a 'Meets Expectations' or higher rating in the most recent Lattice review cycle, and written notification to the current manager prior to final-round interviews.
