# Remote, Hybrid & Temporary International Work Policy

*Document ID: POL-HR-003  |  Version: 3.4  |  Owner: People Operations & Global Mobility  |  Effective Date: February 1, 2026*

## 1. Workplace Operating Model

VantagePoint operates a 'Flexible-First' work model designed to balance deep focused work with intentional in-person collaboration. Every position is designated in Workday under one of three work-location profiles: Hub-Based Hybrid, Designated Remote, or In-Office Essential.

| Work Profile | Eligibility Criteria | In-Office Expectation | Core Collaboration Hours |
|---|---|---|---|
| Hub-Based Hybrid | Residing within 35 miles of Miami HQ, Austin, or Seattle hubs | Minimum 2 days/week (Tuesdays & Thursdays anchor days) | 10:00 AM – 3:00 PM Hub Local Time |
| Designated Remote | Residing >35 miles from a hub in an approved U.S. state | Quarterly team offsites (travel funded under POL-FIN-001) | 11:00 AM – 3:00 PM EST (Core Overlap) |
| In-Office Essential | IT Hardware Ops, Facilities, Workplace Experience, Exec Support | 4–5 days/week on-site as scheduled | 8:30 AM – 5:00 PM Hub Local Time |

## 2. Remote Work Standards & Home Workspace Requirements

Remote and hybrid employees are expected to maintain a safe, ergonomic, and distraction-free workspace capable of supporting uninterrupted video conferencing and secure data handling (see POL-SEC-001).

- Internet Connectivity: Employees must maintain reliable high-speed broadband internet with minimum speeds of 50 Mbps download and 10 Mbps upload. Cellular hotspots are permitted only as emergency backups and never for handling Restricted/Confidential customer data.
- Availability & Responsiveness: During Core Collaboration Hours (11:00 AM – 3:00 PM EST), remote employees must be reachable on Slack within 15 minutes and keep their Google Calendar up to date with working hours and focus blocks.
- Dependent Care: Remote work is not a substitute for full-time childcare or eldercare. While occasional flexibility during school closures or appointments is supported, ongoing caregiving during working hours requires formal leave or flexible schedule arrangements.

## 3. Domestic Relocation & State Tax Compliance

Because payroll tax withholding, workers' compensation, and state employment laws depend on where work is physically performed, employees must request written approval from People Operations at least 30 days before changing their primary residential state.

Approved U.S. Employment States: VantagePoint is currently registered to employ remote workers in 38 U.S. states. Working permanently from an unregistered state (including North Dakota, South Dakota, Wyoming, Alaska, Hawaii, and U.S. territories) is strictly prohibited without prior tax-entity setup.

### 3.1 Compensation Geographic Tiers

Base salaries at VantagePoint are benchmarked across three U.S. geographic compensation zones: Zone 1 (San Francisco Bay Area, NYC Metro, Seattle), Zone 2 (Miami, Austin, Boston, Denver, Chicago, Los Angeles, Washington D.C.), and Zone 3 (All other approved U.S. locations). Relocating from a higher-cost zone to a lower-cost zone triggers a base salary adjustment effective the first pay period following the move; relocating to a higher-cost zone requires prior VP-level budget approval.

## 4. 'Work From Anywhere' (WFA) Temporary Travel Policy

Regular full-time employees in good performance standing (no active PIP) may work temporarily from an alternate domestic or approved international location for up to 30 cumulative calendar days per calendar year, subject to the rules below:

### 4.1 Domestic WFA (Within the United States)

- Up to 30 cumulative days per year in any U.S. state with manager notification at least 5 business days in advance.
- Employees must work their normal core overlap hours regardless of local time zone.

### 4.2 International WFA ('Workcations')

- Maximum Cap: Up to 15 consecutive or cumulative calendar days per year (counted toward the 30-day total WFA allowance).
- Pre-Approval Required: Must submit an International WFA Request in Workday at least 21 days prior to travel for Global Mobility, Tax, and InfoSec clearance.
- Embargoed & High-Risk Countries: Working from OFAC-sanctioned countries or high-risk cybersecurity jurisdictions (including China, Russia, North Korea, Iran, Belarus, Cuba, Venezuela, and Syria) is strictly prohibited. Employees may not bring company laptops or access corporate systems from these jurisdictions even while on personal vacation.
- Visa & Immigration Responsibility: Employees are solely responsible for ensuring their tourist/visitor visa permits remote work activities in the destination country.

## 5. Co-Working Space Day Passes

Designated Remote employees who do not live near a VantagePoint hub may expense up to $250/month for WeWork All Access or local co-working day passes via Expensify (category: WFH-COWORKING), provided the space offers private phone booths for confidential calls.
