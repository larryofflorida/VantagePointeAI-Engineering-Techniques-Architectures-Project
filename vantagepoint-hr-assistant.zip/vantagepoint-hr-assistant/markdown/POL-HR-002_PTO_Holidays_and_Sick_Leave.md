# Paid Time Off (PTO), Company Holidays & Sick Leave Policy

*Document ID: POL-HR-002  |  Version: 5.0  |  Owner: People Operations & Payroll  |  Effective Date: January 1, 2026*

## 1. Overview and Philosophy

VantagePoint believes sustainable high performance requires genuine rest and personal time away from work. We maintain a transparent, accrual-based Paid Time Off (PTO) program for vacation and personal time, paired with a separate dedicated Paid Sick & Safe Leave bank and 13 paid Company Holidays (11 fixed + 2 floating) per calendar year.

## 2. Vacation & Personal PTO Accrual Tiers

Regular full-time employees accrue PTO biweekly across 26 pay periods per year based on continuous length of service. Tenure tier increases take effect on the first day of the pay period following the employee's work anniversary.

| Length of Service | Annual PTO Allowance | Biweekly Accrual Rate | Maximum Rollover Cap | Maximum Balance Ceiling |
|---|---|---|---|---|
| 0 – 2 Years (Months 1–24) | 15 days (120 hours) | 4.62 hours / pay period | 40 hours (5 days) | 160 hours (20 days) |
| 2 – 5 Years (Months 25–60) | 20 days (160 hours) | 6.15 hours / pay period | 60 hours (7.5 days) | 220 hours (27.5 days) |
| 5+ Years (Month 61+) | 25 days (200 hours) | 7.69 hours / pay period | 80 hours (10 days) | 280 hours (35 days) |

### 2.1 Carryover, Maximum Ceiling & Payout Rules

- Year-End Carryover: On December 31 at 11:59 PM EST, unused PTO above the Maximum Rollover Cap is forfeited (except in California, Colorado, Montana, and Nebraska, where state law prohibits forfeiture and accrued PTO rolls over subject to the Maximum Balance Ceiling).
- Accrual Pause at Ceiling: Once an employee's PTO balance reaches the Maximum Balance Ceiling, biweekly accruals pause until PTO is used and the balance drops below the ceiling.
- Negative PTO Borrowing: With written manager and People Partner approval, employees who have completed 90 days of service may borrow up to 40 hours (5 days) of unearned PTO. If employment ends while the balance is negative, the negative balance is deducted from the final paycheck where permitted by state law.
- Payout Upon Separation: Accrued, unused vacation PTO is paid out in full upon voluntary resignation (with at least 2 weeks' notice) or involuntary termination without cause, calculated at the employee's base hourly rate.

## 3. PTO Request & Approval Procedures

All PTO requests must be submitted in Workday Time Off and approved by the direct manager before travel is booked or time is taken. During peak product launch blackouts or fiscal quarter-end close (for Finance/Accounting), managers may require staggered scheduling.

| Duration of Absence | Minimum Advance Notice | Approval Required | Coverage Requirement |
|---|---|---|---|
| 1 – 2 consecutive days | At least 5 business days | Direct Manager | Update Slack status & OOO email |
| 3 – 5 consecutive days | At least 2 weeks (10 business days) | Direct Manager | Written handoff doc + designated backup |
| 6 – 10 consecutive days | At least 4 weeks (20 business days) | Direct Manager + Dept Head | Formal coverage plan shared 1 week prior |
| More than 10 consecutive days | At least 6 weeks | Dept Head + VP People Ops | Executive exception approval required |

## 4. 2026 Official Company Holiday Schedule

VantagePoint observes 11 fixed U.S. Company Holidays (spanning 16 paid days including the Winter Recharge shutdown) plus 2 Floating Holidays. Non-exempt employees required to work on an observed holiday receive 1.5x holiday pay in addition to 8 hours of holiday pay.

| Holiday Name | 2026 Observed Date | Day of Week | Notes |
|---|---|---|---|
| New Year's Day | January 1, 2026 | Thursday | All U.S. Offices Closed |
| Martin Luther King Jr. Day | January 19, 2026 | Monday | All U.S. Offices Closed |
| Presidents' Day | February 16, 2026 | Monday | All U.S. Offices Closed |
| Memorial Day | May 25, 2026 | Monday | All U.S. Offices Closed |
| Juneteenth National Independence Day | June 19, 2026 | Friday | All U.S. Offices Closed |
| Independence Day (Observed) | July 3, 2026 | Friday | Observed Friday for Saturday July 4 |
| Labor Day | September 7, 2026 | Monday | All U.S. Offices Closed |
| Indigenous Peoples' / Veterans Day | November 11, 2026 | Wednesday | All U.S. Offices Closed |
| Thanksgiving Day | November 26, 2026 | Thursday | All U.S. Offices Closed |
| Day After Thanksgiving | November 27, 2026 | Friday | All U.S. Offices Closed |
| Winter Break / Christmas Shutdown | December 24 – December 31, 2026 | Thursday – Thursday | Year-End Company Recharge (6 paid days) |

### 4.1 Floating Holidays

Full-time employees hired before July 1 receive two (2) Floating Holidays (16 hours) per calendar year to observe cultural, religious, or personal milestones. Employees hired between July 1 and September 30 receive one (1) Floating Holiday; those hired on or after October 1 are eligible starting January 1 of the following year. Floating Holidays must be used by December 31 and do not carry over or pay out upon separation.

## 5. Paid Sick & Safe Leave

Separate from vacation PTO, all full-time employees receive 80 hours (10 days) of Paid Sick & Safe Leave front-loaded on January 1 each year (prorated by hire month for mid-year hires). Part-time employees accrue 1 hour of sick leave for every 30 hours worked.

### 5.1 Qualifying Uses

- Diagnosis, care, or treatment of an employee's own physical or mental illness, injury, or preventive medical/dental appointments.
- Care for an ill family member (spouse, domestic partner, child, parent, sibling, grandparent, grandchild, or any individual related by blood or affinity whose close association is the equivalent of a family relationship).
- Safe Leave: Absence due to domestic violence, sexual assault, or stalking (obtaining legal protection, relocation, victim services, or counseling).
- Public health closure of the employee's workplace or a child's school/daycare.

### 5.2 Notification & Documentation

Employees must notify their manager via Slack or email at least 1 hour before their scheduled shift start when possible. A healthcare provider's note is required only for sick absences exceeding three (3) consecutive workdays. Unused Paid Sick & Safe Leave rolls over up to 80 hours per year (or higher where mandated by local ordinance such as Seattle, NYC, or California) and is never paid out upon termination.

## 6. Bereavement, Jury Duty & Voting Leave

- Bereavement Leave: Up to 10 paid days following the loss of an immediate family member (spouse, partner, child, parent, sibling) and up to 5 paid days for extended family (grandparent, aunt, uncle, cousin, in-law). Pregnancy loss and failed adoption/IVF placements qualify for the 10-day immediate family tier.
- Jury Duty & Witness Leave: Full regular base pay for up to 15 business days per calendar year when summoned for jury service or subpoenaed as a non-party witness. Employees must upload the court summons in Workday.
- Election Voting Leave: Up to 4 hours of paid time off on Election Day if polling hours do not allow 3 consecutive off-duty hours to vote.
- Volunteer Time Off (VTO): Full-time employees receive 16 hours (2 days) of paid Volunteer Time Off per calendar year to volunteer with a registered 501(c)(3) nonprofit organization, logged in Workday under 'Volunteer Leave'.
