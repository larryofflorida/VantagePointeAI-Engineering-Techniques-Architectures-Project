# Compensation, Payroll Schedule, Overtime & Performance Review Policy

*Document ID: POL-COMP-001  |  Version: 3.0  |  Owner: Total Rewards & Payroll Operations  |  Effective Date: January 1, 2026*

## 1. Pay Schedule & Timekeeping

VantagePoint pays all U.S. employees on a biweekly payroll cycle (26 pay periods per year), with direct deposits issued every other Friday. When a scheduled payday falls on a bank or Company holiday (POL-HR-002), direct deposit is issued on the preceding business day.

- Pay Stubs & Tax Documents: Electronic pay statements and annual Forms W-2 are accessible via Workday Pay. Payroll inquiries or direct deposit updates must be submitted at least 5 business days before payday.
- Non-Exempt Timekeeping: Non-exempt (hourly) employees must accurately record all hours worked, including meal breaks, daily in Workday Time Tracking. Working 'off the clock' is strictly prohibited.

## 2. Overtime & Meal/Rest Break Compliance

Non-exempt employees must obtain written manager approval prior to working overtime. Regardless of pre-approval, all recorded overtime hours will be paid in full (unauthorized overtime may be addressed through coaching under POL-ETH-001).

- Federal Overtime Standard: Non-exempt employees receive 1.5x their regular rate of pay for all hours worked in excess of 40 hours in a standard Sunday–Saturday workweek.
- California & State-Specific Daily Overtime: Non-exempt employees working in California receive 1.5x pay for hours worked over 8 in a workday (up to 12 hours) and 2.0x double-time for hours over 12 in a workday or over 8 hours on the 7th consecutive workday.
- Meal & Rest Periods: Non-exempt employees working more than 5 hours in a shift must take an uninterrupted, duty-free unpaid meal break of at least 30 minutes before the end of the 5th hour, plus a paid 15-minute rest break for every 4 hours worked.

## 3. Performance Review & Merit Compensation Cycles

VantagePoint conducts biannual performance calibrations in Lattice to ensure fair, transparent career progression and merit rewards:

| Review Cycle | Evaluation Window | Calibration & Delivery | Compensation Impact |
|---|---|---|---|
| Mid-Year Check-In | June 1 – June 30 | Manager & peer 360 feedback delivered by July 15 | Mid-year promotions (for high-impact readiness) effective August 1 |
| Annual Performance & Merit Review | December 1 – January 15 | Calibrated ratings delivered by February 10 | Annual merit base salary increases, equity refreshers, and annual bonus payouts effective March 1 |

## 4. Annual Corporate Bonus & Employee Referral Program

### 4.1 Annual Corporate Performance Bonus

Regular full-time employees not on a sales commission plan participate in the Annual Corporate Bonus Plan with target bonus percentages ranging from 10% (L1–L4) to 20% (Directors+). Payouts are weighted 60% on Company ARR/EBITDA attainment and 40% on individual performance rating. Employees hired after October 1 are ineligible for that calendar year's bonus; hires between January 1 and September 30 receive a prorated payout.

### 4.2 Employee Referral Bonus Program

Employees who refer a candidate hired into a regular full-time role receive a referral bonus paid out after the referred hire completes 90 days of continuous employment:

- Standard Roles (L1–L4): $3,000 gross referral bonus.
- Senior Technical, Product & Leadership Roles (L5+): $5,000 gross referral bonus.

Hiring managers, People Operations, Talent Acquisition, and VP+ executives are ineligible for referral bonuses for hires within their own reporting chain.
