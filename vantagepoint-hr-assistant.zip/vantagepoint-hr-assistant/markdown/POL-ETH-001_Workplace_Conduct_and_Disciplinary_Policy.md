# Code of Workplace Conduct, Anti-Harassment & Progressive Discipline

*Document ID: POL-ETH-001  |  Version: 4.5  |  Owner: People Operations & Legal Compliance  |  Effective Date: January 1, 2026*

## 1. Equal Employment Opportunity & Respectful Workplace

VantagePoint Technologies Inc. is an equal opportunity employer committed to fostering an inclusive, respectful, and psychologically safe environment. We strictly prohibit discrimination, harassment, or retaliation based on race, color, religion, sex (including pregnancy, childbirth, sexual orientation, and gender identity), national origin, age (40+), disability, genetic information, veteran status, or any other characteristic protected by federal, state, or local law.

This policy applies across all physical offices, remote workspaces, Slack channels, Zoom calls, company-sponsored social events, offsites, and client engagements.

## 2. Anti-Harassment & Non-Retaliation

- Unlawful Harassment: Includes unwelcome verbal, visual, or physical conduct—such as slurs, offensive jokes, derogatory memes in Slack, unwanted sexual advances, quid pro quo requests, or displaying explicit imagery—that creates an intimidating, hostile, or offensive work environment.
- Reporting Channels: Employees who experience or witness misconduct should report it promptly to any People Partner, the Chief Legal Officer, or anonymously 24/7 via the EthicsPoint Hotline (ethics.vantagepoint.example.com or +1-888-555-0144).
- Zero Tolerance for Retaliation: VantagePoint strictly prohibits retaliation against any individual who reports a concern in good faith or participates in an internal investigation. Retaliation is an independent violation subject to termination.

## 3. Conflicts of Interest, Outside Employment & Gifts

### 3.1 Outside Employment ('Moonlighting')

Full-time employees may engage in outside consulting, teaching, or board service only if it: (a) occurs strictly outside working hours without using company equipment or IP, (b) does not involve a competitor, customer, or vendor of VantagePoint, and (c) is disclosed in writing and approved in advance by Legal Compliance via the Conflict of Interest Disclosure Form.

### 3.2 Business Gifts & Hospitality

Employees may not solicit gifts from vendors or clients. Unsolicited nominal gifts (such as branded swag or holiday gift baskets) valued under $100 USD may be accepted. Gifts exceeding $100 must be politely declined or reported to Legal Compliance for donation/raffle. Cash, gift cards, and loans from vendors are strictly prohibited regardless of value.

## 4. Workplace Alcohol, Substance-Free Policy & Office Etiquette

- Alcohol at Company Events: Moderate alcohol consumption is permitted only at sanctioned company celebrations (e.g., quarterly socials, offsite dinners) for attendees aged 21+. Non-alcoholic alternatives must always be prominently offered. Operating a vehicle while impaired or exhibiting intoxicated behavior is strictly prohibited.
- Illegal Substances: Possession, sale, or working under the influence of illegal drugs or non-prescribed controlled substances on company premises or during working hours is prohibited.
- Hub Quiet Zones & Meeting Room Etiquette: Hub offices feature designated 'Library Quiet Zones' where phone/video calls are prohibited. Conference rooms left unoccupied 10 minutes past the scheduled start time are automatically released in Google Calendar.

## 5. Progressive Discipline & Performance Improvement

While employment at VantagePoint is at-will, the Company generally follows a structured progressive discipline framework for performance or minor policy infractions:

| Step | Action | Documentation & Duration | Approval Required |
|---|---|---|---|
| Step 1 | Verbal Coaching / Counseling | Manager follow-up email summarizing expectations | Direct Manager |
| Step 2 | Written Warning | Formal warning placed in Workday personnel file; 30-day review | Direct Manager + People Partner |
| Step 3 | Performance Improvement Plan (PIP) or Final Written Warning | 30- to 60-day structured PIP with measurable milestones and weekly check-ins | Dept Head + HR Director |
| Step 4 | Termination of Employment | Involuntary separation upon failure to meet PIP or severe misconduct | VP People Ops + Legal |

Immediate Termination Offenses: Severe infractions—including violence or threats of violence, theft, intentional security breaches, expense fraud, unlawful harassment, or working from an OFAC-embargoed country—bypass progressive steps and result in immediate termination.
