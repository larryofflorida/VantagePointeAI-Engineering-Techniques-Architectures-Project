# IT Equipment, Hardware Lifecycle & Home Office Stipend Policy

*Document ID: POL-IT-001  |  Version: 4.0  |  Owner: Information Technology & Workplace Operations  | Effective Date: January 15, 2026*

## 1. Standard Issue Computing Hardware

VantagePoint provides every regular employee with company-owned, MDM-enrolled (Jamf Pro / Microsoft Intune) computing hardware tailored to their role. All company hardware remains the sole property of VantagePoint Technologies Inc.

| Role Track | Primary Laptop Specification | Standard Peripherals Included | Refresh Cycle |
|---|---|---|---|
| General / Business / Ops | 14-inch Apple MacBook Pro (M4, 16GB RAM, 512GB SSD) OR Dell Latitude 7450 (32GB RAM) | USB-C Multiport Hub, YubiKey 5C NFC (x2), Laptop Sleeve | Every 36 months (3 years) |
| Engineering / Data / Design | 16-inch Apple MacBook Pro (M4 Pro, 36GB RAM, 1TB SSD) | 27-inch 4K USB-C Monitor (shipped on request), YubiKey 5C NFC (x2) | Every 36 months (3 years) |
| Executive / Frequent Travel | 13-inch MacBook Air (M4, 24GB RAM, 512GB SSD) + Cellular iPad Mini | Privacy Screen Filter, International Travel Adapter, YubiKey 5C NFC | Every 30 months |

## 2. Home Office Setup & Monthly Connectivity Stipends

### 2.1 One-Time Home Office Setup Allowance ($1,000)

All newly hired regular full-time employees receive a one-time reimbursement allowance of up to $1,000 USD (taxable as imputed income per IRS guidelines) during their first 90 days of employment to purchase ergonomic home office equipment.

- Eligible Items: Ergonomic office chair, standing desk or desk converter, external monitor(s), mechanical keyboard, ergonomic mouse, webcam, ring light/desk lamp, noise-canceling headset, surge protector, and docking station.
- Ineligible Items: Smartphones, tablets, smartwatches, televisions, gaming consoles, home decor/art, rugs, coffee machines, and monthly utility bills.
- Reimbursement Process: Submit itemized receipts in Expensify under report tag 'NEW-HIRE-WFH' within 90 days of start date. Unused balances expire on Day 91. Items purchased with this stipend belong to the employee.

### 2.2 Monthly Internet & Mobile Phone Stipend ($100/month)

Regular full-time employees receive a flat $100/month ($50 per biweekly paycheck) non-accountable communications allowance to offset home broadband and personal mobile data usage used for Slack, Okta Verify, and business calls. Because this allowance is paid automatically through payroll, employees may not separately expense monthly home internet or personal cell phone bills in Expensify (except international roaming packages pre-approved for business travel under POL-FIN-001).

## 3. Hardware Care, Loss, Theft & Accidental Damage

Employees must exercise reasonable care to protect company hardware from physical damage, liquid spills, extreme temperatures, and theft.

- Accidental Damage: All company laptops carry AppleCare+ for Enterprise or Dell ProSupport Plus. First accidental damage incident is covered at no cost to the employee. Subsequent accidental damage incidents within a 12-month period may require manager review.
- Lost or Stolen Devices: Must be reported to the IT Security Incident Hotline (+1-800-555-0199) and #it-helpdesk within 2 hours of discovery so IT can execute a remote lock/wipe. For stolen devices, employees must file a local police report within 24 hours and upload the case number to the IT ticket.
- Unattended Devices: Never leave laptops visible inside parked vehicles, checked airline luggage, or unattended in public cafes/airports. Devices must always travel in carry-on baggage.

## 4. Software Procurement, BYOD & Offboarding Returns

### 4.1 Approved Software & SaaS

Employees may only install software from the VantagePoint Self-Service App Catalog (Jamf/Company Portal). Purchasing or signing up for unapproved cloud SaaS tools or AI transcription bots ('Shadow IT') using a corporate email address is prohibited unless reviewed by InfoSec and Procurement.

### 4.2 Bring Your Own Device (BYOD)

Accessing company Slack, Gmail, or Google Drive on a personal smartphone is permitted only if the device runs a supported OS version (iOS 18+ or Android 15+), has biometric/passcode lock enabled, and enrolls in Okta FastPass / Google Endpoint Verification. Local downloading of company files onto personal phones or personal computers is strictly prohibited.

### 4.3 Offboarding & Equipment Return

Upon resignation or termination, IT sends a prepaid FedEx/UPS return shipping kit with insured tracking to the employee's address on file. All company-owned laptops, monitors, YubiKeys, and badges must be dropped off with the carrier within seven (7) calendar days of the separation date. Failure to return company hardware may result in invoicing for depreciated replacement value and legal recovery.
